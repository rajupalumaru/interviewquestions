const Validate = (values) => {
    let errors = {};
    const regName = /^[a-zA-Z\s]*$/g;
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    var regularExpression = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
     var num = '1234567890';
  
    if (!values.name) {
      errors.name = "Name is required field";
    } else if (!regName.test(values.name)) {
      errors.name = "Please enter valid name";
    }
  
    if (!values.email) {
      errors.email = "Email is required field";
    } else if (!regex.test(values.email)) {
      errors.email = "Please enter valid email";
    }
  
    if (!values.password) {
      errors.password = "Password is required field";
    } else if (!regularExpression.test(values.password)) {
      errors.password = "pwd pattern mismatch";
    } else if (values.password.length < 8) {
      errors.password = "password must be more than 8 characters";
    }

    if (!values.Confirmpassword) {
        errors.Confirmpassword = "Password is required field";
      } else if (!regularExpression.test(values.Confirmpassword)) {
        errors.Confirmpassword = "pwd pattern mismatch";
      } else if (values.Confirmpassword.length < 8) {
        errors.Confirmpassword = "password must be more than 8 characters";
      }

    if (!values.phonenumber) {
        errors.phonenumber = "phonenumber is required field";
      } else if (!(num.match('[0-9]{10}'))) {
        errors.phonenumber = "please enter valid number";
      } else if (values.phonenumber.length != 10 ) {
        errors.phonenumber = "Enter valid number";
      }
  
      if (!values.AlternatePhonenumber) {
        errors.AlternatePhonenumber = "phonenumber is required field";
      } else if (!(num.match('[0-9]{10}'))) {
        errors.AlternatePhonenumber = "please enter valid number";
      } else if (values.AlternatePhonenumber.length != 10 ) {
        errors.AlternatePhonenumber = "Enter valid number";
      }
      // pincode
      if (!values.Pincode) {
        errors.Pincode = "Pincode is required field";
      } else if (!(num.match('[0-9]{10}'))) {
        errors.Pincode = "please enter valid pincode";
      } else if (values.Pincode.length < 6) {
        errors.Pincode = "Enter valid pincode";
      }

      if (!values.Streetaddress) {
        errors.Streetaddress = "Invalid enter address";
      }

      if (!values.City) {
        errors.City = "Please enter required fields";
      }

      if (!values.State) {
        errors.State = "Please enter required fields";
      }

  
    if (!values.Dob) {
      errors.Dob = "Please enter required fields";
    }
  

    if (!values.Companyname) {
        errors.Companyname = "Please enter required fields";
      }

      if (!values.IDcardnumber) {
        errors.IDcardnumber = "Please enter required fields";
      }

      


    return errors;
  };
  export default Validate;
  